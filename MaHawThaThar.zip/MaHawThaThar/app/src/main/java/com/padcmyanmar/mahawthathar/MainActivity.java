package com.padcmyanmar.mahawthathar;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;

import com.padcmyanmar.mahawthathar.adapters.NewBookAdapter;
import com.padcmyanmar.mahawthathar.fragments.FeatureFragment;
import com.padcmyanmar.mahawthathar.fragments.NewBookFragment;
import com.padcmyanmar.mahawthathar.fragments.PopularFragment;

public class MainActivity extends AppCompatActivity {
    DrawerLayout bookDrawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        //attach rc view with book item
        RecyclerView rcNewBook=findViewById(R.id.rv_newbooks);
        rcNewBook.setFocusable(false);
        rcNewBook.setLayoutManager(new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false));

        NewBookAdapter newBookAdapter=new NewBookAdapter();
        rcNewBook.setAdapter(newBookAdapter);
        bookDrawer=findViewById(R.id.drawer_layout);


        //connect feature fragment
        showFeatureFragment();

        //connect popular fragment
        showPopularFragment();

        //set click action for toolbar
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "hello", Toast.LENGTH_SHORT).show();
                bookDrawer.openDrawer(GravityCompat.START);
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
       /* if (id == R.id.action_settings) {
            return true;
        }*/

        return super.onOptionsItemSelected(item);
    }
    public void showFeatureFragment()
    {
        getSupportFragmentManager().beginTransaction().replace(R.id.fl_feature_container, FeatureFragment.newInstance()).addToBackStack(null).commit();
    }

    public void showPopularFragment()
    {
        getSupportFragmentManager().beginTransaction().replace(R.id.fl_popular_container, PopularFragment.newInstance()).commit();
    }
}
