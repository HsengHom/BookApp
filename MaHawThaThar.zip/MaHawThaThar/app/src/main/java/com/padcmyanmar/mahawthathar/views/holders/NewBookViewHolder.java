package com.padcmyanmar.mahawthathar.views.holders;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;

public class NewBookViewHolder extends RecyclerView.ViewHolder {

    public NewBookViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
