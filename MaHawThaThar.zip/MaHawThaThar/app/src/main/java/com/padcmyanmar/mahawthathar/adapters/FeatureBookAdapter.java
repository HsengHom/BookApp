package com.padcmyanmar.mahawthathar.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.padcmyanmar.mahawthathar.R;
import com.padcmyanmar.mahawthathar.views.holders.FeatureViewHolder;

import java.util.zip.Inflater;

public class FeatureBookAdapter extends RecyclerView.Adapter<FeatureViewHolder> {
    @NonNull
    @Override
    public FeatureViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater= LayoutInflater.from(viewGroup.getContext());
        View itemView=inflater.inflate(R.layout.feature_item,viewGroup,false);
        return  new FeatureViewHolder(itemView);

    }

    @Override
    public void onBindViewHolder(@NonNull FeatureViewHolder featureViewHolder, int i) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }
}
